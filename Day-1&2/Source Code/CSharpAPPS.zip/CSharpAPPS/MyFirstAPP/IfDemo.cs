﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class IfDemo
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Value:");
            int a=int.Parse(Console.ReadLine());

            Console.WriteLine("Enter b value:");
            int b=int.Parse(Console.ReadLine());

            Console.WriteLine("Enter c value:");
            int c=int.Parse(Console.ReadLine());

            if(a>b && a>c)
            {
                Console.WriteLine($"{a} is Bigger Than {b} and {c}");
            }
            else if(b>c)
            {
                Console.WriteLine($"{b} is Bigger Than {a} and {c}");
            }
            else
            {
                Console.WriteLine($"{c} is Bigger Than {a} and {b}");
            }
        }
    }
}
