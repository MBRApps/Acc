﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class ArrayDemo2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter array size:");
            int n=int.Parse(Console.ReadLine());

            string[] courses = new string[n];

            //reading values into array
            for(int i = 0;i<courses.Length;i++)
            {
                Console.WriteLine($"Enter value for Index-{i}:");
                courses[i] = Console.ReadLine();
            }

            //printing array values
            for(int i=0;i<courses.Length;i++)
            {
                Console.WriteLine(courses[i]);
            }
        }
    }
}
