﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    class Product
    {
        public int Id;
        public string Name;
        public double Price;
        public void print()
        {
            Console.WriteLine($"{Id}-{Name}-{Price}");
        }
    }
    internal class ArraysWithClasses
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Number of Products:");
            int size=int.Parse(Console.ReadLine());

            Product[] arr=new Product[size];

            //read product details
            for(int i=0; i<arr.Length; i++)
            {
                arr[i]=new Product();

                Console.WriteLine("Enter Id:");
                arr[i].Id=int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Name:");
                arr[i].Name = Console.ReadLine();

                Console.WriteLine("Enter Price:");
                arr[i].Price=double.Parse(Console.ReadLine());

            }

            double totalcost = 0;
            //printing product details
            for (int i = 0; i < arr.Length; i++)
            {
                totalcost+= arr[i].Price;
                arr[i].print();
            }
            Console.WriteLine($"Total:{totalcost}");

        }
    }
}
