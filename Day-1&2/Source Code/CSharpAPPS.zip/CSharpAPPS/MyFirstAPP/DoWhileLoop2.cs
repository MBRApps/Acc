﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class DoWhileLoop2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter First Number:");
            int a = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter Second Number:");
            int b = int.Parse(Console.ReadLine());

            bool x = false;
            do
            {
                Console.WriteLine("1.Add\n2.Sub\n3.Mul\n0.Exit\nEnter Choice:");
                int n = int.Parse(Console.ReadLine());

                if (n == 1)
                {
                    Console.WriteLine(a + b);
                }
                else if (n == 2)
                {
                    Console.WriteLine(a - b);
                }
                else if (n == 3)
                {
                    Console.WriteLine(a * b);
                }
                else if (n == 0)
                {
                    x = false;
                }
                else
                {
                    Console.WriteLine("Wrong Choice!");
                }
            }
            while (x);//x==true
        }
    }
}
