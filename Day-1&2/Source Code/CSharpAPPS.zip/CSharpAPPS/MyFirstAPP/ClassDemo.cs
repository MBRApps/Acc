﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    class Employee
    {
        public int Id;
        public string Name;
        public int Age;
        public string Designation;

        public void print()
        {
            Console.WriteLine($"{Id}-{Name}-{Designation}");
        }
    }
    internal class ClassDemo
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            emp.Id = 101;
            emp.Name = "Steve";
            emp.Age = 30;
            emp.Designation = "IT-Dev";
            emp.print();
        }
    }
}
