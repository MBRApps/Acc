﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    class IEmployee
    {
        public int EmpId;
        public string Name;
        public string Designation;
        public void print()
        {
            Console.WriteLine($"{EmpId}-{Name}-{Designation}");
        }
    }
    internal class EmployeeDemo
    {
        static void Main(string[] args)
        {
            /*Console.WriteLine("Enter Employee Id:");
            int _id=int.Parse(Console.ReadLine());*/

            IEmployee emp = new IEmployee()
            {
                EmpId = 1,Name="Steve",Designation="Tester"
            };
            emp.print();
        }
    }
}
