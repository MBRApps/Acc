﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    class Parent
    {
        public void Show()
        {
            Console.WriteLine("This is from parent");
        }
    }
    class Child1:Parent
    {
        public void Print()
        {
            Console.WriteLine("This is from Child");
        }
    }
    class Child2:Parent
    {
        public void display()
        {
            Console.WriteLine("This is From Grand Child");
        }
    }

    internal class InheritanceDemo
    {
        static void Main(string[] args)
        {
            /* Parent parent=new Parent();
             parent.Show();

             Child child=new Child();
             child.Print();
             child.Show();*/

            Child1 c1 = new Child1();
            c1.Show();
            c1.Print();

            Child2 c2=new Child2();
            c2.Show();
            c2.display();
        }
    }
}
