﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    class Student
    {
        int _id;
        string _name;
        int _age;

        public int Id { get => _id; set => _id = value; }
        public string Name { get => _name; set => _name = value; }
        public int Age { get => _age; set => _age = value; }

        public override string ToString()
        {
            return $"Id:{Id}\nName:{Name}\nAge:{Age}";
        }
        public override bool Equals(object? obj)
        {
            Student student = (Student)obj;
            if(student.Id==Id && student.Name==Name)
            {
                return true;
            }
            return false;
        }
        public override int GetHashCode()
        {
            return base.GetHashCode()*96;
        }
    }

    internal class StudentDemo
    {
        static void Main(string[] args)
        {
            Student s1 = new Student()
            {
                Id = 1,Name="Bill Gates",Age=60
            };
            Console.WriteLine(s1.ToString());

            Student s2 = new Student()
            {
                Id = 1,
                Name = "Bill Gates",
                Age = 65
            };

            if(s1.Equals(s2))
            {
                Console.WriteLine("Both are Equal");
            }
            else
            {
                Console.WriteLine("Not Equal");
            }

            Console.WriteLine(s1.GetHashCode());
            Console.WriteLine(s2.GetHashCode());
        }
    }
}
