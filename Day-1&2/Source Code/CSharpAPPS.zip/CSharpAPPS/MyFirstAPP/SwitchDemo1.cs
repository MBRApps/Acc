﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class SwitchDemo1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Number:");
            int a =int.Parse(Console.ReadLine());

            Console.WriteLine("Enter a Number:");
            int b = int.Parse(Console.ReadLine());

            Console.WriteLine("1.Add\n2.Sub\n3.Mul\nEnter Choice:");
            int n=int.Parse(Console.ReadLine());

            switch(n)
            {
                case 1:
                    Console.WriteLine(a+b);
                    break;
                case 2:
                    Console.WriteLine(a - b);
                    break;
                case 3:
                    Console.WriteLine(a * b);
                    break;
                default:
                    Console.WriteLine("Invalid choice");
                    break;
            }
        }
    }
}
