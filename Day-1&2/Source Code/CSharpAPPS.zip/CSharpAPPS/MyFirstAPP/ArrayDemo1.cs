﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class ArrayDemo1
    {
        static void Main(string[] args)
        {
            string[] courses = {"React","C","C++","Java","Sql","PHP" };

            Array.Sort(courses);
            Array.Reverse(courses);

            //for(int i=0; i<courses.Length; i++) 
            //{
            //    Console.WriteLine(courses[i]);
            //}

            foreach (var c in courses) 
            {
                Console.WriteLine(c);
            }

        }
    }
}
