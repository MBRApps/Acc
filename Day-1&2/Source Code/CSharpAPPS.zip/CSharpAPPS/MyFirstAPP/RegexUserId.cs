﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class RegexUserId
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter UserId:");
            string inp = Console.ReadLine();

            if (Regex.IsMatch(inp, "^[A-Za-z]{1}[A-Za-z0-9._@]{7,19}$"))
            {
                Console.WriteLine("Valid UserID");
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
        }
    }
}
