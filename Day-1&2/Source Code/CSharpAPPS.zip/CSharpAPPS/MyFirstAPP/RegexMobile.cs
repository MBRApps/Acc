﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class RegexMobile
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Mobile No:");
            string inp = Console.ReadLine();

            if(Regex.IsMatch(inp, "^[6-9]{1}[0-9]{9}$"))
            {
                Console.WriteLine("Valid MobileNo.");
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
        }
    }
}
