﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class ReadingInput2
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter First Number:");
            double a = double.Parse(Console.ReadLine());
            //int a = int.Parse(Console.ReadLine());


            Console.WriteLine("Enter Second Number:");
            double b = double.Parse(Console.ReadLine());
            //int b = int.Parse(Console.ReadLine());

            Console.WriteLine($"The sum of {a} and {b} is {a+b}");

        }
    }
}
