﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class Triangle1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Number:");
            int n = int.Parse(Console.ReadLine());
            int count = 1;
            for (int i = 1; i <=n; i++)
            {
                for(int j=1;j<=i; j++)
                {
                    //Console.Write($"{j} ");
                    //Console.Write($"* ");
                    Console.Write($"{count} ");
                    count += 1;
                }
                Console.WriteLine();
            }
        }
    }
}
