﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class RegexPAN
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter PAN No:");
            string inp = Console.ReadLine();

            if (Regex.IsMatch(inp, "^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$"))
            {
                Console.WriteLine("Valid PAN No.");
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
        }
    }
}
