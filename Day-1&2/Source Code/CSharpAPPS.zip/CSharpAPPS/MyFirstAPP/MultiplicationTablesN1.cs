﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class MultiplicationTablesN1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Number:");
            int n = int.Parse(Console.ReadLine());

            for (int i = 1; i <= 10; i++) //1
            {
                //Console.Write($"{n-1} X {i} = {(n-1) * i}   ");
                //Console.Write($"{n} X {i} = {n * i}   ");
                //Console.Write($"{n+1} X {i} = {(n+1) * i}   ");
                for(int j=-1;j<=1;j++)
                {
                    Console.Write($"{n+j} X {i} = {(n+j) * i}   ");
                }
                Console.WriteLine();
            }
        }
    }
}
