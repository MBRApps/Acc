﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class ForDemo
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Number:");
            int n=int.Parse(Console.ReadLine());
           /* for (int i = 1; i <=n; i++)
            {
                //Console.WriteLine("Hello");
                Console.WriteLine(i);
            }*/
           for(int i=n;i>=1;i--)
            {
                Console.WriteLine(i);
            }
        }
    }
}
