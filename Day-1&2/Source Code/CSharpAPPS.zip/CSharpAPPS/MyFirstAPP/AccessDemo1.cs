﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    class Demo1
    {
        public int a = 15;
        public void print()
        {
            Console.WriteLine(a);
        }
    }
    class Demo2:Demo1
    {
        public int b = 25;
    }
    internal class AccessDemo1
    {
        static void Main(string[] args)
        {
            Demo1 d1 = new Demo1();
            d1.a = 40;
            Console.WriteLine(d1.a);
            d1.print();

            Demo2 d2 = new Demo2();
            Console.WriteLine(d2.a);
        }
    }
}
