﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class WhileLoop1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Number:");
            int n=int.Parse(Console.ReadLine());

            int i = 1;
            while(i<=n)
            {
                Console.WriteLine(i);
                i++;
            }
        }
    }
}
