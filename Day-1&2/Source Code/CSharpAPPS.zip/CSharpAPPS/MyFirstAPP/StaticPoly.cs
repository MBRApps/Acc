﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    class Arithematic
    {
        public void sum(int x,int y)
        {
            Console.WriteLine(x+y);
        }
        public void sum(int a, int b,int c)
        {
            Console.WriteLine(a+b+c);
        }
    }
    internal class StaticPoly
    {
        static void Main(string[] args)
        {
            Arithematic ar = new Arithematic();
            ar.sum(10, 25);
            ar.sum(15, 25, 69);
        }
    }
}
