﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class MultiplicationTablesN
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Number:");
            int n = int.Parse(Console.ReadLine());

            for(int i=1;i<=10; i++) //1
            {
                for(int j=1;j<=n; j++)
                {
                    Console.Write($"{j} X {i} = {j*i}   ");
                }
                Console.WriteLine();
            }
        }
    }
}
