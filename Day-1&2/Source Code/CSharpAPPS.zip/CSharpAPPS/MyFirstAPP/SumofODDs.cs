﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class SumofODDs
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a Number:");
            int n = int.Parse(Console.ReadLine());

            int count = 0;
            for(int i=1;i<=n;i++)
            {
                if (i % 2 != 0)
                {
                    count += i;
                }
                
            }
            Console.WriteLine("Total:"+count);
        }
    }
}
