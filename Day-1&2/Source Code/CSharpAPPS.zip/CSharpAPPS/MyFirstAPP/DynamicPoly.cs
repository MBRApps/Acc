﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    class BankV1
    {
        public virtual void Withdraw(double amount)
        {
            Console.WriteLine("Withdraw using Net Banking");
        }
    }
    class BankV2:BankV1
    {
        public override void Withdraw(double amount)
        {
            Console.WriteLine("Withdraw using UPI");
        }
    }
    internal class DynamicPoly
    {
        static void Main(string[] args)
        {
            BankV2 v2 = new BankV2();
            v2.Withdraw(5500);
        }
    }
}
