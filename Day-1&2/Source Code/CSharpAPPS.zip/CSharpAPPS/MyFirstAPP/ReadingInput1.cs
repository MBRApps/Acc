﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class ReadingInput1
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter First Name:");
            string FName=Console.ReadLine();

            Console.WriteLine("Enter Last Name:");
            string LName= Console.ReadLine();

            Console.WriteLine($"Hello {FName} {LName} Good Afternoon...");
        }
    }
}
