﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFirstAPP
{
    internal class SumOfArrayElements
    {
        static void Main(string[] args)
        {
            int[] scores = new int[6];

            for (int i = 0; i < scores.Length; i++)
            {
                Console.WriteLine($"Enter Value for Subject-{i+1}:");
                scores[i]=int.Parse(Console.ReadLine());
            }

            int total = 0;
            for (int i = 0; i < scores.Length; i++)
            {
                //total += scores[i];
                total = total + scores[i];
            }
            Console.WriteLine($"Total Scores:{total}");
        }
    }
}
