﻿namespace MyFirstAPP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a=58;
            int b = 98;

            int sum = a + b;
            Console.WriteLine(sum);
            Console.WriteLine("The sum of "+a+" and "+b+" is "+sum);//string concat
            Console.WriteLine("The sum of {0} and {1} is {2}",a,b,sum);//string arguments
            Console.WriteLine($"The sum of {a} and {b} is {sum}");//string formation
        }
    }
}