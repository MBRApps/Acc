﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class FileHandling2
    {
        static void Main(string[] args)
        {
            string fpath = @"D:\sample.txt";            
            if (File.Exists(fpath))
            {
                StreamWriter sw = new StreamWriter(fpath,append:true);
                sw.WriteLine("----------------------------");
                sw.WriteLine(DateTime.Now.ToString("dd-MM-yyyy hh:mm:ss"));
                sw.WriteLine("Hello World");
                sw.WriteLine("This is sample text from C# Program");
                sw.Close();
            }
            else
            {
                Console.WriteLine("Incorrect FilePath/File Not Found!!");
            }
        }
    }
}
