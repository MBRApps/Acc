﻿namespace ConsoleApp1
{
    abstract class Arithematic
    {
        public void sum(int x,int y)
        {
            Console.WriteLine(x+y);
        }
        public void sub(int x, int y)
        {
            Console.WriteLine(x - y);
        }
        public abstract void mul(int x, int y);
    }
    class Demo : Arithematic
    {
        public override void mul(int x, int y)
        {
            Console.WriteLine(x*y);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Demo d1 = new Demo();
            d1.sum(10, 20);
            d1.sub(10, 20);
            d1.mul(10, 20);
        }
    }
}