﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class FileHandling3
    {
        static void Main(string[] args)
        {
            string fpath = @"D:\sample.txt";
            if (File.Exists(fpath))
            {
                StreamReader sr = new StreamReader(fpath);
                /*int charval;
                while((charval=sr.Read())!=-1)
                {
                    Console.Write((char)charval);
                }*/
                string line;
                while((line=sr.ReadLine())!=null)
                {
                    Console.WriteLine(line);
                }
            }
            else
            {
                Console.WriteLine("Incorrect FilePath/File Not Found!!");
            }
        }
    }
}
