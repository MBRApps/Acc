﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Parent
    {
        public string message = "Good AfterNoon";
        public Parent()
        {
            Console.WriteLine("Parent Class Empty Constructor Invoked!");
        }
        public Parent(int i)
        {
            Console.WriteLine("Parent Class Parameterized Constructor Invoked!");
        }
    }
    class Child : Parent
    {
        public Child()
        {
            Console.WriteLine("Child Class Empty Constructor Invoked!");
        }
        public Child(int j):base(j)
        {
            Console.WriteLine("Child Class Parameterized Constructor Invoked!");
        }

        public void print()
        {
            Console.WriteLine(base.message);
        }
    }
    internal class BaseKeyword
    {
        static void Main(string[] args)
        {
            Child child=new Child(16);
            child.print();
        }
    }
}
