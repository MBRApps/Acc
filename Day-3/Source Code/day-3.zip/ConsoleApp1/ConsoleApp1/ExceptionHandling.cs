﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class ExceptionHandling
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("***********Try**************");
                Console.WriteLine("Enter a Number:");
                int i = int.Parse(Console.ReadLine());
                i++;
                Console.WriteLine($"After Increment:{i}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine("***********Format Exception Catch**************");
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("***********Catch**************");
                Console.WriteLine(ex);
            }
            finally
            {
                Console.WriteLine("***********Finally**************");
            }
        }
    }
}
