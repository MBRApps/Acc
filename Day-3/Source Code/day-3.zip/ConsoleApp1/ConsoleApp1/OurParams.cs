﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class IDemo
    {
        public void printName(string FName, string LName, out string FullName)
        {
            FullName = FName + " " + LName;
        }       
    }
    internal class OurParams
    {
        static void Main(string[] args)
        {
            IDemo d1 = new IDemo();
            string fullname;
            d1.printName("Steve", "Jobs", out fullname);
            Console.WriteLine(fullname);
        }
    }
}
