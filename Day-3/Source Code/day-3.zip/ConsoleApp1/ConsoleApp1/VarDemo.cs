﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class VarDemo
    {
        static void Main(string[] args)
        {
            var i=15;
            dynamic d;
            d = 10;
            Console.WriteLine($"value:{d}");
            d = 15.26;
            Console.WriteLine($"value:{d}");
            d = 'C';
            Console.WriteLine($"value:{d}");
            d = "india";
            Console.WriteLine($"value:{d}");
        }
    }
}
