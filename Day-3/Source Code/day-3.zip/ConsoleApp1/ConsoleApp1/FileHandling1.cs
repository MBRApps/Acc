﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ConsoleApp1
{
    internal class FileHandling1
    {
        static void Main(string[] args)
        {
            string fpath = @"D:\sample.txt";
            File.Create(fpath);
            if(File.Exists(fpath))
            {
                Console.WriteLine("File Created Successfully!");
            }
            else
            {
                Console.WriteLine("Something went wrong!");
            }
        }
    }
}
