﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class ExceptionHandling2
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("***********Try**************");
               
                Console.WriteLine("Enter First Value:");
                int i = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Second Value:");
                int j = int.Parse(Console.ReadLine());

                double result = i / j;
                Console.WriteLine(result);

            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine("***********DivideByZeroException Catch**************");
                Console.WriteLine("You Can't Divide by Zero");
            }
            catch (Exception ex)
            {
                Console.WriteLine("***********Catch**************");
                Console.WriteLine(ex);
            }
            finally
            {
                Console.WriteLine("***********Finally**************");
            }
        }
    }
}
