﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class FileHandling6
    {
        static void Main(string[] args)
        {
            string sfpath = @"D:\sample.txt";
            string dfpath = @"D:\demo.txt";
            if (File.Exists(sfpath))
            {
               File.Copy(sfpath, dfpath,false);
                if(File.Exists(dfpath))
                {
                    Console.WriteLine("File copied Successfully");
                }
            }
            else
            {
                Console.WriteLine("Incorrect FilePath/File Not Found!!");
            }
        }
    }
}
