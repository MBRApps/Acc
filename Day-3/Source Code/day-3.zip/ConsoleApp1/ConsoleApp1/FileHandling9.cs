﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class FileHandling9
    {
        static void Main(string[] args)
        {
            string dirpath = @"D:\Dotnet\CSharp\sample\03Nov2023\";
            if(Directory.Exists(dirpath)) 
            {
               string[] filelist= Directory.GetFiles(dirpath);
                foreach(string filepath in filelist )
                {
                    FileInfo fi=new FileInfo(filepath);
                    Console.WriteLine(fi.FullName);
                    Console.WriteLine(fi.Name);
                    Console.WriteLine(fi.Directory);
                    Console.WriteLine(fi.DirectoryName);
                    Console.WriteLine(fi.CreationTime);
                    Console.WriteLine(fi.Length+" Bytes");
                    Console.WriteLine("-----------------------------");
                }
            }
        }
    }
}
