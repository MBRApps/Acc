﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class student
    {
        public int Id;
        public string Name;
        public static string CollegeName="ABC College";
        public override string ToString()
        {
            return $"{Id}-{Name}-{CollegeName}";
        }
        public static void printMsg()
        {
            Console.WriteLine("Hello User! Good Afternoon");
        }
    }
    internal class StaticDemo
    {
        static void Main(string[] args)
        {
            student.CollegeName = "XYZ Engineering & Technology";
            student s1 = new student {Id=1,Name="John" };
            student s2 = new student {Id=2,Name="Steve"};
            Console.WriteLine(s1.ToString());
            Console.WriteLine(s2.ToString());
            student.printMsg();

        }
    }
}
