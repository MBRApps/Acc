﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Product
    {
        public Product()
        {
            Console.WriteLine("Empty Constructor Invoked!");
        }
        public Product(string s)
        {
            Console.WriteLine("Parameterized Constructor Invoked!");
        }
    }
    internal class ConstructorsDemo
    {
        static void Main(string[] args)
        {
            Product prod = new Product();
            Product prod1 = new Product("india");
        }
    }
}
