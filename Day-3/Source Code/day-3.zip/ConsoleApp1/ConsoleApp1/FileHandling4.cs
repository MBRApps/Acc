﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class FileHandling4
    {
        static void Main(string[] args)
        {
            string fpath = @"D:\sample.txt";
            if (File.Exists(fpath))
            {
                string[] lines = {"This is Line-1", "This is Line-2", "This is Line-3" };
                //File.WriteAllLines(fpath, lines);
                File.AppendAllLines(fpath, lines);
            }
            else
            {
                Console.WriteLine("Incorrect FilePath/File Not Found!!");
            }
        }
    }
}
