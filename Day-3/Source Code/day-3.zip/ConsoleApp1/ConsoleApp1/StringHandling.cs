﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class StringHandling
    {
        static void Main(string[] args)
        {
            string str = "india";
            Console.WriteLine(str);
            Console.WriteLine(str+"(+91)");
            Console.WriteLine(str);

            /* StringBuilder sb = new StringBuilder("india");
             Console.WriteLine(sb);
             sb.Append("(+91)");
             Console.WriteLine(sb);*/

            string s = "i am from INDIA";
            Console.WriteLine(s);
            Console.WriteLine(s.ToUpper());
            Console.WriteLine(s.ToLower());
            Console.WriteLine(s.Length);
            Console.WriteLine(s.Replace('m','#'));
            Console.WriteLine(s.Replace("INDIA","HYDERABAD"));

            Console.WriteLine(s.PadLeft(20,'#'));
            Console.WriteLine(s.PadRight(20,'#'));

            string s1 = "     india    ";
            Console.WriteLine(s1.TrimStart());
            Console.WriteLine(s1.TrimEnd());
            Console.WriteLine(s1.Trim());

            string s2 = "$$$$$$$$$india$$$$$$$$$$$$";
            Console.WriteLine(s2);
            Console.WriteLine(s2.TrimStart('$'));
            Console.WriteLine(s2.TrimEnd('$'));
            Console.WriteLine(s2.Trim('$'));

            string ss1 = "I am From INDIA";
            string ss2 = "I AM FROM INDIA";
            Console.WriteLine(ss1.Equals(ss2));
            Console.WriteLine(ss1.Equals(ss2,StringComparison.InvariantCultureIgnoreCase));
            Console.WriteLine(ss1.CompareTo(ss2));

            Console.WriteLine(ss1.StartsWith("I am"));
            Console.WriteLine(ss1.EndsWith("INDIA"));
            Console.WriteLine(ss1.Contains("From"));

            foreach (string sp1 in ss1.Split(' '))
            {
                Console.WriteLine(sp1);
            }
        }
    }   
}
