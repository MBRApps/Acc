﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class FileHandling7
    {
        static void Main(string[] args)
        {
            string fpath = @"D:\sample.txt";
            if (File.Exists(fpath))
            {
                FileInfo fi=new FileInfo(fpath);
                Console.WriteLine(fi.FullName);
                Console.WriteLine(fi.Name);
                Console.WriteLine(fi.Extension);
                Console.WriteLine(fi.Directory);
                Console.WriteLine(fi.DirectoryName);
                Console.WriteLine(fi.Length +" Bytes");
            }
            else
            {
                Console.WriteLine("Incorrect FilePath/File Not Found!!");
            }
        }
    }
}
