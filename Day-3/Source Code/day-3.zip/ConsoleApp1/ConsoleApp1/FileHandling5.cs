﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class FileHandling5
    {
        static void Main(string[] args)
        {
            string fpath = @"D:\sample.txt";
            if (File.Exists(fpath))
            {
               string[] lines= File.ReadAllLines(fpath);
                foreach (string line in lines)
                {
                    Console.WriteLine(line);
                }
            }
            else
            {
                Console.WriteLine("Incorrect FilePath/File Not Found!!");
            }
        }
    }
}
