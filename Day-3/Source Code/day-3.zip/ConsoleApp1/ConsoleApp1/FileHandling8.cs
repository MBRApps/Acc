﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class FileHandling8
    {
        static void Main(string[] args)
        {
            string dirpath = @"D:\Dotnet\CSharp\sample\03Nov2023\";
            Directory.CreateDirectory(dirpath);
            if(Directory.Exists(dirpath)) 
            {
                Console.WriteLine("Folder(s) created successfully!");
            }
            else
            {
                Console.WriteLine("Somthing went wrong!");
            }
        }
    }
}
