﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class DateTimeDemo
    {
        static void Main(string[] args)
        {
            DateTime dt= DateTime.Now;
            //DateTime dt = DateTime.Parse("2005-12-31 15:25:32");
            DateTime dt1 = DateTime.ParseExact("31/12/2005 15:25:32", "dd/MM/yyyy HH:mm:ss", null);
            Console.WriteLine(dt);

            Console.WriteLine(dt.Year);
            Console.WriteLine(dt.Month);
            Console.WriteLine(dt.Day);
            Console.WriteLine(dt.Hour);
            Console.WriteLine(dt.Minute);
            Console.WriteLine(dt.Second);
            Console.WriteLine(dt.Millisecond);

            Console.WriteLine(dt.AddDays(100));
            Console.WriteLine(dt.AddDays(-100));

            Console.WriteLine(dt.DayOfWeek);
            Console.WriteLine(dt.DayOfYear);

            double days = (dt - dt1).TotalDays;
            Console.WriteLine("{0:0.00}",days);

             int years=dt.Year - dt1.Year;
            Console.WriteLine(years);

            Console.WriteLine(DateTime.IsLeapYear(dt.Year));
            Console.WriteLine(DateTime.IsLeapYear(dt1.Year));

            Console.WriteLine(dt.ToString());
            Console.WriteLine(dt.ToString("dd-MM-yyyy hh:mm:ss tt"));
            Console.WriteLine(dt.ToString("dd-MMM-yyyy hh:mm:ss tt"));
            Console.WriteLine(dt.ToString("dd-MMMM-yyyy hh:mm:ss tt"));
            Console.WriteLine(dt.ToString("ddMMyyyyHHmmss"));
        }
    }
}
