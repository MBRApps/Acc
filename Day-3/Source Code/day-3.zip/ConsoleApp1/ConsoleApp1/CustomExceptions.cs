﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class InsuffecientFundsException:Exception
    {
        public InsuffecientFundsException()
            :base("Insuffecient Amount in Account")
        {
            
        }
    }

    internal class CustomExceptions
    {
        static void Main(string[] args)
        {
            try
            {
                int balance = 25000;
                Console.WriteLine("Enter Amount to withdraw:");
                int amount = int.Parse(Console.ReadLine());

                if (amount <= balance)
                {
                    balance -= amount;
                    Console.WriteLine
                     ($"Transaction Successfull!\n Available Balance:{balance}");
                }
                else
                {
                    throw new InsuffecientFundsException();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
