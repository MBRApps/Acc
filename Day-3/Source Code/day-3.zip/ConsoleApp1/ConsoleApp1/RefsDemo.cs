﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class TestArth
    {
        public void increment(ref int i)
        {
            i++;
        }
    }

    internal class RefsDemo
    {
        static void Main(string[] args)
        {
            TestArth ar = new TestArth();
            int x = 10;
            ar.increment(ref x);
            Console.WriteLine(x);
        }
    }
}
