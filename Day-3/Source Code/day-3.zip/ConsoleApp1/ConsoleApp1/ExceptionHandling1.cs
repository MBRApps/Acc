﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class ExceptionHandling1
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("***********Try**************");
                string[] courses = { "C", "C++", "Java", "Angular" };
                Console.WriteLine("Enter Index:");
                int i = int.Parse(Console.ReadLine());

                Console.WriteLine(courses[i]);

            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine("***********IndexOutOfRangeException Catch**************");
                Console.WriteLine("Please enter valid Index");
            }
            catch (Exception ex)
            {
                Console.WriteLine("***********Catch**************");
                Console.WriteLine(ex);
            }
            finally
            {
                Console.WriteLine("***********Finally**************");
            }
        }
    }
}
