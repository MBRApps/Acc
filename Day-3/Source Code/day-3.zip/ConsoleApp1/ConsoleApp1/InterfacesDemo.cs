﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    interface IArithematic
    {
        void sum(int a, int b);
        void sub(int a, int b);
        void mul(int a, int b);
    }
    class ArthematicDemo : IArithematic
    {
        public void mul(int a, int b)
        {
            Console.WriteLine(a*b);
        }

        public void sub(int a, int b)
        {
            Console.WriteLine(a-b);
        }

        public void sum(int a, int b)
        {
            Console.WriteLine(a+b);
        }
    }
    internal class InterfacesDemo
    {
        static void Main(string[] args)
        {
            IArithematic demo = new ArthematicDemo();
            demo.sum(10, 20);
            demo.sub(10, 20);
            demo.mul(10, 20);
        }
    }
}
