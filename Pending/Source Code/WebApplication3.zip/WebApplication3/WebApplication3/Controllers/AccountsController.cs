﻿using Microsoft.AspNetCore.Mvc;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class AccountsController : Controller
    {
        public List<string> users = new List<string>()
        {
            "User1",
            "User2",
            "User3",
            "User4",
            "User5"

        };
        public IActionResult Login()
        {
            TempData["userdata"] = users;
            HttpContext.Session.SetString("UserId", "admin");
            return View();
        }

        [HttpPost]
        public IActionResult Login(UserLogin lg)
        {
            if (lg.UserId == lg.Password)
            {
                return RedirectToAction("Index", "password");
            }
            else
            {
                ViewBag.msg = "Incorrect UserId/Password";
            }
            return View();
        }
    }
}
