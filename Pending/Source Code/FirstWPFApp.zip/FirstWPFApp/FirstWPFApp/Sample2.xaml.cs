﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FirstWPFApp
{
    /// <summary>
    /// Interaction logic for Sample2.xaml
    /// </summary>
    public partial class Sample2 : Page
    {
        public Sample2()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            List<string> cities = new List<string> { "Mumbai","Pune","Delhi"};
            /*foreach (var x in cities)
            {
                cmbCity.Items.Add(x);
            }*/

            cmbCity.ItemsSource= cities;


        }

        private void cmbCity_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            lblResult.Content=cmbCity.SelectedItem.ToString();
        }
    }
}
