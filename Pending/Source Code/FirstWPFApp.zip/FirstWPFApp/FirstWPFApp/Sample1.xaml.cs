﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FirstWPFApp
{
    /// <summary>
    /// Interaction logic for Sample1.xaml
    /// </summary>
    public partial class Sample1 : Window
    {
        public Sample1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            int v1 = int.Parse(txtValue1.Text);
            int v2 = int.Parse(txtValue2.Text);
            lblResult.Content="Sum:"+(v1+v2);
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtValue1.Text = "0";
            txtValue2.Text = "0";
        }

        public void sum()
        {
            try
            {
                int v1 = int.Parse(txtValue1.Text);
                int v2 = int.Parse(txtValue2.Text);
                lblResult.Content = "Sum:" + (v1 + v2);
            }
            catch
            {
               
            }
        }
        private void txtValue1_KeyUp(object sender, KeyEventArgs e)
        {
            sum();
        }

        private void txtValue2_KeyUp(object sender, KeyEventArgs e)
        {
            sum();
        }
    }
}
