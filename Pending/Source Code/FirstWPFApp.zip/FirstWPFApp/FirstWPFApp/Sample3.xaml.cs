﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FirstWPFApp
{
    /// <summary>
    /// Interaction logic for Sample3.xaml
    /// </summary>
    public partial class Sample3 : Window
    {
        public Sample3()
        {
            InitializeComponent();
        }

        private void rbtnMale_Checked(object sender, RoutedEventArgs e)
        {
            lblResult.Content = rbtnMale.Content + " is Selected";
            //lblResult.FontSize = 16;
        }

        private void rbtnFemale_Checked(object sender, RoutedEventArgs e)
        {
            lblResult.Content = rbtnFemale.Content + " is Selected";
            //lblResult.FontSize = 16;
            
        }
    }
}
