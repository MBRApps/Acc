﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FirstWPFApp
{
    /// <summary>
    /// Interaction logic for Sample5.xaml
    /// </summary>
    public partial class Sample5 : Window
    {
        public Sample5()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            var document = txtFeedback.Document;
            var content=new TextRange(document.ContentStart,document.ContentEnd);
            lblResult.Content=content.Text;

        }
    }
}
