﻿using System.ComponentModel.DataAnnotations;
using System.Diagnostics.Contracts;

namespace WebApplication2.Models
{
    public class UserLogin
    {
        [Required]
        public string UserId { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
