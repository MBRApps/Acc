﻿using Microsoft.EntityFrameworkCore;

namespace EFCoreSample.Models
{
    public class OfficeContext:DbContext
    {
        public OfficeContext()
        {

        }

        public OfficeContext(DbContextOptions options):base(options)
        {
            
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=DESKTOP-L1SMRMH;Initial Catalog=TestDBNov07;Integrated security=true;TrustServerCertificate=true");
        }
        public DbSet<Employee> Employees { get; set; }
    }
}
