﻿using System.ComponentModel.DataAnnotations;

namespace EFCoreSample.Models
{
    public class Employee
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        [DataType(DataType.EmailAddress)]
        public string email { get; set; }
    }
}
