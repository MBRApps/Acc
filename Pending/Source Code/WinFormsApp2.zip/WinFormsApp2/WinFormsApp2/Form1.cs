namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //this.BackColor = Color.Blue;

            //lblName.Text = Directory.GetCurrentDirectory();



        }

        private void txtName_KeyUp(object sender, KeyEventArgs e)
        {
            txtName.Text = txtName.Text.ToUpper();
        }

        private void btnColor_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
            this.BackColor = colorDialog1.Color;
            txtName.Text = dateTimePicker1.Text;


        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            txtName.Text = trackBar1.Value.ToString();
            progressBar1.Value = trackBar1.Value;
        }
    }
}