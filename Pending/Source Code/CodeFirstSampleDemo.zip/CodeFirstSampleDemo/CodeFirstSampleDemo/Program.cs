﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodeFirstSampleDemo
{
    class Employee
    {
        [Key]
        public int EmployeeId { get; set; }
        public string Name { get; set; }
        public string Designation { get; set; }
        public string City { get; set; }
    }
    class OfficeEntities:DbContext
    {
        public OfficeEntities():base("dbconn")
        {
            
        }

        public DbSet<Employee> Employees { get; set; }
    }
    internal class Program
    {
        static void Insert()
        {
            using (OfficeEntities db=new OfficeEntities())
            {
                Employee emp = new Employee 
                {
                    Name="Harry",Designation="IT-DEV",City="Hyderabad" 
                };
                db.Employees.Add(emp);
                if(db.SaveChanges()>0)
                {
                    Console.WriteLine("Inserted Successfully");
                }
                else
                {
                    Console.WriteLine("Something went wrong");
                }
            }
        }
        static void Main(string[] args)
        {
            Insert();
        }
    }
}
