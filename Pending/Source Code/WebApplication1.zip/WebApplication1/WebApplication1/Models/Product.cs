﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    class EmailValidator:ValidationAttribute
    {
        public override bool IsValid(object? value)
        {
            string inp = (string)value;
            if(inp.EndsWith("@accenture.com"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
    public class Product
    {
        [Key]
        [Required]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public double Price { get; set; }

        [Required]
        [RegularExpression("^[ARar]{1}[A-Za-z0-9]{9}$",ErrorMessage ="Invalid Barcode")]
        public string Barcode { get; set; }

        [EmailValidator(ErrorMessage ="")]
        public string Email { get; set; }
    }
}
