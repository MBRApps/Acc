﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ProductsController : Controller
    {
        public static List<Product> Products = new List<Product>()
        {
            new Product{ Id=1,Name="Test Prodict1",Barcode="B012345678",Price=8500},
            new Product{ Id=2,Name="Test Prodict2",Barcode="B012345688",Price=14200},
            new Product{ Id=3,Name="Test Prodict3",Barcode="B012345698",Price=16980},
            new Product{ Id=4,Name="Test Prodict4",Barcode="B012345679",Price=4500},
            new Product{ Id=5,Name="Test Prodict5",Barcode="B012345680",Price=82500},
        };
        [HttpGet]
        public IActionResult Index()
        {
            return View(Products);
        }

        [HttpPost]
        public IActionResult Index(string name, int age)
        {
            return View();
        }

        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(Product prod)
        {
            prod.Id = Products.Max(x => x.Id) + 1;
            Products.Add(prod);
            return View();
        }

        [HttpGet]

        public IActionResult Delete(int id)
        {
            Product prod = Products.Where(x => x.Id == id).FirstOrDefault();
            Products.Remove(prod);
            //return View();
            return RedirectToAction("Index", "Products");
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            Product prod = Products.Where(x => x.Id == id).FirstOrDefault();
            return View(prod);
        }

        [HttpPost]

        public IActionResult Edit(Product prod)
        {
            Product product = Products.Where(x => x.Id == prod.Id).FirstOrDefault();
            product.Barcode = prod.Barcode;
            product.Name = prod.Name;
            product.Price= prod.Price;

            return RedirectToAction("Index", "Products"); 
        }
    }
}
