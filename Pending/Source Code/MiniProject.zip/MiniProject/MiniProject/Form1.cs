using System.Data;
using System.Data.SqlClient;

namespace MiniProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtUserId.Text = txtPassword.Text = "";
            txtUserId.Focus();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            using (SqlConnection con=new SqlConnection(Common.getConnstring()))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandType = System.Data.CommandType.Text;
                cmd.CommandText = "select * from Usermaster where UserId=@uid and Password=@pwd";
                cmd.Parameters.AddWithValue("@uid", txtUserId.Text);
                cmd.Parameters.AddWithValue("@pwd", txtPassword.Text);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                if(dt.Rows.Count>0)
                {
                    string role = dt.Rows[0]["Role"].ToString();
                    if(role=="1")
                    {
                        frmAdmin fa = new frmAdmin();
                        fa.Show();
                        this.Hide();
                    }
                    else
                    {
                        frmUser f = new frmUser();
                        f.Show();
                        this.Hide();
                    }
                }
                else
                {
                    MessageBox.Show("Incorrect UserId/Password");
                }
            }
        }
    }
}