﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiniProject
{
    internal class Common
    {
        public static string getConnstring()
        {
            return "Data Source=DESKTOP-L1SMRMH;Initial Catalog=TruYum;Integrated Security=true";
        }
    }
}
