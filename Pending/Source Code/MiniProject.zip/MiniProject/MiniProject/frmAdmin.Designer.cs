﻿namespace MiniProject
{
    partial class frmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            transactionToolStripMenuItem = new ToolStripMenuItem();
            addMenuItemsToolStripMenuItem = new ToolStripMenuItem();
            viewMenuItemsToolStripMenuItem = new ToolStripMenuItem();
            editMenuItemsToolStripMenuItem = new ToolStripMenuItem();
            deleteMenuItemsToolStripMenuItem = new ToolStripMenuItem();
            logoutToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { transactionToolStripMenuItem, logoutToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 38);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // transactionToolStripMenuItem
            // 
            transactionToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { addMenuItemsToolStripMenuItem, viewMenuItemsToolStripMenuItem, editMenuItemsToolStripMenuItem, deleteMenuItemsToolStripMenuItem });
            transactionToolStripMenuItem.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point);
            transactionToolStripMenuItem.Name = "transactionToolStripMenuItem";
            transactionToolStripMenuItem.Size = new Size(133, 34);
            transactionToolStripMenuItem.Text = "Transaction";
            // 
            // addMenuItemsToolStripMenuItem
            // 
            addMenuItemsToolStripMenuItem.Name = "addMenuItemsToolStripMenuItem";
            addMenuItemsToolStripMenuItem.Size = new Size(270, 34);
            addMenuItemsToolStripMenuItem.Text = "Add Menu Items";
            // 
            // viewMenuItemsToolStripMenuItem
            // 
            viewMenuItemsToolStripMenuItem.Name = "viewMenuItemsToolStripMenuItem";
            viewMenuItemsToolStripMenuItem.Size = new Size(270, 34);
            viewMenuItemsToolStripMenuItem.Text = "View Menu Items";
            // 
            // editMenuItemsToolStripMenuItem
            // 
            editMenuItemsToolStripMenuItem.Name = "editMenuItemsToolStripMenuItem";
            editMenuItemsToolStripMenuItem.Size = new Size(270, 34);
            editMenuItemsToolStripMenuItem.Text = "Edit Menu Items";
            // 
            // deleteMenuItemsToolStripMenuItem
            // 
            deleteMenuItemsToolStripMenuItem.Name = "deleteMenuItemsToolStripMenuItem";
            deleteMenuItemsToolStripMenuItem.Size = new Size(270, 34);
            deleteMenuItemsToolStripMenuItem.Text = "Delete Menu Items";
            // 
            // logoutToolStripMenuItem
            // 
            logoutToolStripMenuItem.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point);
            logoutToolStripMenuItem.ForeColor = Color.Red;
            logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            logoutToolStripMenuItem.Size = new Size(93, 34);
            logoutToolStripMenuItem.Text = "Logout";
            logoutToolStripMenuItem.Click += logoutToolStripMenuItem_Click;
            // 
            // frmAdmin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            FormBorderStyle = FormBorderStyle.None;
            MainMenuStrip = menuStrip1;
            Name = "frmAdmin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmAdmin";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem transactionToolStripMenuItem;
        private ToolStripMenuItem viewMenuItemsToolStripMenuItem;
        private ToolStripMenuItem editMenuItemsToolStripMenuItem;
        private ToolStripMenuItem deleteMenuItemsToolStripMenuItem;
        private ToolStripMenuItem logoutToolStripMenuItem;
        private ToolStripMenuItem addMenuItemsToolStripMenuItem;
    }
}